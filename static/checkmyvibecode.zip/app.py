import html as html_module
import json
import os
import re
import secrets
import urllib.parse
import urllib.request
from flask import Flask, Response, send_from_directory, abort, redirect, url_for, request, session, render_template
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')

BLOCKED_NAMES = {'.env', '.git', 'app.py', 'requirements.txt'}
HTML_ENTRY_POINTS = {'index.html', 'checkmyvibecode-app.html'}

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY') or secrets.token_hex(32)

SUPABASE_URL        = os.environ.get('SUPABASE_URL', '')
SUPABASE_ANON_KEY   = os.environ.get('SUPABASE_ANON_KEY', '')
SUPABASE_SERVICE_KEY = os.environ.get('SUPABASE_SERVICE_KEY', '')
ADMIN_PASSWORD      = os.environ.get('ADMIN_PASSWORD', '')
RESEND_API_KEY = os.environ.get('RESEND_API_KEY', '')

BASE_URL_OVERRIDE = os.environ.get('BASE_URL', '').rstrip('/')

# ── Helpers ───────────────────────────────────────────────────────────────────

def _inject_config(html):
    """Inject Supabase config into the HTML <head>."""
    config = json.dumps({'url': SUPABASE_URL, 'anonKey': SUPABASE_ANON_KEY})
    script = f'<script>window.SUPABASE_CONFIG={config};</script>\n'
    return html.replace('</head>', script + '</head>', 1)


def serve_app():
    with open(os.path.join(BASE_DIR, 'checkmyvibecode-app.html'), 'r', encoding='utf-8') as f:
        html = f.read()
    base_url = BASE_URL_OVERRIDE or request.host_url.rstrip('/')
    html = html.replace('__BASE_URL__', base_url)
    html = _inject_config(html)
    resp = Response(html, mimetype='text/html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    return resp

def _fetch_project(project_id):
    """Fetch a single project from Supabase REST API (for OG tag injection)."""
    if not SUPABASE_URL or not SUPABASE_ANON_KEY:
        return None
    try:
        safe_id = urllib.parse.quote(str(project_id), safe='')
        api_url = (
            f"{SUPABASE_URL}/rest/v1/projects"
            f"?id=eq.{safe_id}"
            f"&select=id,name,description,emoji,author,cat"
            f"&status=eq.approved"
            f"&limit=1"
        )
        req = urllib.request.Request(api_url, headers={
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': f'Bearer {SUPABASE_ANON_KEY}',
        })
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode())
            return data[0] if data else None
    except Exception:
        return None


def _inject_project_og(html, project):
    """Replace generic OG / Twitter title + description with project-specific values."""
    name   = project.get('name', '') or ''
    emoji  = project.get('emoji', '') or ''
    desc   = project.get('description', '') or ''
    if len(desc) > 250:
        desc = desc[:247] + '...'

    title = f"{emoji} {name} — CheckMyVibeCode" if emoji else f"{name} — CheckMyVibeCode"
    safe_title = html_module.escape(title)
    safe_desc  = html_module.escape(desc)

    html = re.sub(r'<title>[^<]*</title>', f'<title>{safe_title}</title>', html, count=1)
    og_tags = (
        f'<meta property="og:title" content="{safe_title}">\n'
        f'<meta property="og:description" content="{safe_desc}">\n'
        f'<meta name="twitter:title" content="{safe_title}">\n'
        f'<meta name="twitter:description" content="{safe_desc}">\n'
    )
    html = html.replace('<head>', '<head>\n' + og_tags, 1)
    return html


# ── Supabase admin helpers (use service key — bypasses RLS) ───────────────────

def _sb_service_request(method, path, body=None):
    """Make a Supabase REST request using the service role key."""
    if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
        return None, 'SUPABASE_SERVICE_KEY is not configured'
    url = f"{SUPABASE_URL}/rest/v1/{path}"
    data = json.dumps(body).encode() if body is not None else None
    headers = {
        'apikey': SUPABASE_SERVICE_KEY,
        'Authorization': f'Bearer {SUPABASE_SERVICE_KEY}',
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
    }
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode()), None
    except urllib.error.HTTPError as e:
        return None, f'HTTP {e.code}: {e.read().decode()}'
    except Exception as ex:
        return None, str(ex)


def _admin_list_projects(status='pending'):
    safe_s = urllib.parse.quote(status, safe='')
    path = f"projects?status=eq.{safe_s}&order=created_at.asc&select=id,name,description,emoji,author,cat,status,upvotes,demo,tools,created_at"
    data, err = _sb_service_request('GET', path)
    return data or [], err


def _admin_count_by_status():
    counts = {'pending': 0, 'approved': 0, 'rejected': 0}
    for status in counts:
        safe_s = urllib.parse.quote(status, safe='')
        path = f"projects?status=eq.{safe_s}&select=id"
        data, _ = _sb_service_request('GET', path)
        counts[status] = len(data) if data else 0
    return counts


def _admin_set_status(project_id, new_status):
    safe_id = urllib.parse.quote(str(project_id), safe='')
    path = f"projects?id=eq.{safe_id}"
    _, err = _sb_service_request('PATCH', path, {'status': new_status})
    return err


# ── Public routes ─────────────────────────────────────────────────────────────

@app.route('/')
def index():
    pid = request.args.get('project', '').strip()
    if pid:
        return redirect(url_for('project_detail', project_id=pid), code=301)
    return serve_app()

@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory(STATIC_DIR, path)


def _fetch_profile_stats(handle):
    """Fetch build count + total upvotes for a user handle from Supabase REST."""
    if not SUPABASE_URL or not SUPABASE_ANON_KEY:
        return None
    try:
        safe_h = urllib.parse.quote(str(handle), safe='')
        api_url = (
            f"{SUPABASE_URL}/rest/v1/projects"
            f"?author=eq.{safe_h}"
            f"&status=eq.approved"
            f"&select=upvotes"
        )
        req = urllib.request.Request(api_url, headers={
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': f'Bearer {SUPABASE_ANON_KEY}',
        })
        with urllib.request.urlopen(req, timeout=3) as resp:
            rows = json.loads(resp.read().decode())
            return {
                'builds': len(rows),
                'upvotes': sum(r.get('upvotes', 0) or 0 for r in rows),
            }
    except Exception:
        return None


@app.route('/u/<handle>')
def user_profile(handle):
    bare_handle = handle.lstrip('@')
    db_handle   = '@' + bare_handle
    with open(os.path.join(BASE_DIR, 'checkmyvibecode-app.html'), 'r', encoding='utf-8') as f:
        html = f.read()
    base_url = BASE_URL_OVERRIDE or request.host_url.rstrip('/')
    html = html.replace('__BASE_URL__', base_url)
    stats = _fetch_profile_stats(db_handle)
    title = f"{db_handle} — CheckMyVibeCode"
    if stats is not None:
        desc = f"{stats['builds']} build{'s' if stats['builds'] != 1 else ''} · {stats['upvotes']} upvotes on CheckMyVibeCode"
    else:
        desc = f"View {db_handle}'s builds on CheckMyVibeCode"
    safe_t  = html_module.escape(title)
    safe_d  = html_module.escape(desc)
    html    = re.sub(r'<title>[^<]*</title>', f'<title>{safe_t}</title>', html, count=1)
    og_tags = (
        f'<meta property="og:title" content="{safe_t}">\n'
        f'<meta property="og:description" content="{safe_d}">\n'
        f'<meta name="twitter:title" content="{safe_t}">\n'
        f'<meta name="twitter:description" content="{safe_d}">\n'
    )
    html = html.replace('<head>', '<head>\n' + og_tags, 1)
    html = _inject_config(html)
    resp = Response(html, mimetype='text/html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    return resp


@app.route('/p/<project_id>')
def project_detail(project_id):
    with open(os.path.join(BASE_DIR, 'checkmyvibecode-app.html'), 'r', encoding='utf-8') as f:
        html = f.read()
    base_url = BASE_URL_OVERRIDE or request.host_url.rstrip('/')
    html = html.replace('__BASE_URL__', base_url)
    project = _fetch_project(project_id)
    if project:
        html = _inject_project_og(html, project)
    html = _inject_config(html)
    resp = Response(html, mimetype='text/html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    return resp


# ── Admin routes ──────────────────────────────────────────────────────────────

def _admin_logged_in():
    return session.get('admin') is True


def _csrf_token():
    """Return (generating if needed) a per-session CSRF token."""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return session['csrf_token']


def _csrf_valid():
    """Check that the submitted form CSRF token matches the session token."""
    return request.form.get('csrf_token') == session.get('csrf_token')


@app.route('/admin')
def admin():
    if not _admin_logged_in():
        return render_template('admin.html', logged_in=False, error=None,
                               csrf_token=_csrf_token())

    tab = request.args.get('tab', 'pending')
    if tab not in ('pending', 'approved', 'rejected'):
        tab = 'pending'

    projects, err = _admin_list_projects(tab)
    counts = _admin_count_by_status()

    flash_msg  = session.pop('flash_msg', None)
    flash_type = session.pop('flash_type', 'ok')

    return render_template(
        'admin.html',
        logged_in=True,
        projects=projects,
        counts=counts,
        tab=tab,
        flash_msg=flash_msg,
        flash_type=flash_type,
        csrf_token=_csrf_token(),
    )


@app.route('/admin/login', methods=['POST'])
def admin_login():
    if not _csrf_valid():
        return render_template('admin.html', logged_in=False,
                               error='Invalid request. Please try again.',
                               csrf_token=_csrf_token())
    password = request.form.get('password', '')
    if not ADMIN_PASSWORD:
        return render_template('admin.html', logged_in=False,
                               error='ADMIN_PASSWORD secret is not configured.',
                               csrf_token=_csrf_token())
    if password == ADMIN_PASSWORD:
        session['admin'] = True
        return redirect(url_for('admin'))
    return render_template('admin.html', logged_in=False,
                           error='Incorrect password. Try again.',
                           csrf_token=_csrf_token())


@app.route('/admin/logout', methods=['POST'])
def admin_logout():
    if not _csrf_valid():
        return redirect(url_for('admin'))
    session.pop('admin', None)
    return redirect(url_for('admin'))


@app.route('/admin/action', methods=['POST'])
def admin_action():
    if not _admin_logged_in():
        return redirect(url_for('admin'))
    if not _csrf_valid():
        session['flash_msg']  = 'Invalid request token. Please try again.'
        session['flash_type'] = 'err'
        return redirect(url_for('admin'))

    project_id = request.form.get('project_id', '').strip()
    action     = request.form.get('action', '').strip()

    if not project_id or action not in ('approve', 'reject'):
        session['flash_msg']  = 'Invalid action.'
        session['flash_type'] = 'err'
        return redirect(url_for('admin'))

    new_status = 'approved' if action == 'approve' else 'rejected'
    err = _admin_set_status(project_id, new_status)

    if err:
        session['flash_msg']  = f'Error: {err}'
        session['flash_type'] = 'err'
    else:
        verb = 'approved' if new_status == 'approved' else 'rejected'
        session['flash_msg']  = f'Project {verb} successfully.'
        session['flash_type'] = 'ok'

    return redirect(url_for('admin', tab='pending'))


# ── Email notification helper ─────────────────────────────────────────────────

def _send_resend_email(to, subject, text_body):
    """Send a plain-text email via Resend API. Returns (ok, error_msg)."""
    if not RESEND_API_KEY:
        return False, 'RESEND_API_KEY not configured'
    payload = json.dumps({
        'from': 'CheckMyVibeCode <noreply@checkmyvibecode.com>',
        'to': [to],
        'subject': subject,
        'text': text_body,
    }).encode()
    req = urllib.request.Request(
        'https://api.resend.com/emails',
        data=payload,
        headers={
            'Authorization': f'Bearer {RESEND_API_KEY}',
            'Content-Type': 'application/json',
        },
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status < 300, None
    except urllib.error.HTTPError as e:
        return False, f'HTTP {e.code}: {e.read().decode()[:200]}'
    except Exception as ex:
        return False, str(ex)


def _verify_supabase_token(token):
    """Verify a Supabase JWT via /auth/v1/user. Returns user dict or None."""
    if not SUPABASE_URL or not SUPABASE_ANON_KEY or not token:
        return None
    try:
        req = urllib.request.Request(
            f"{SUPABASE_URL}/auth/v1/user",
            headers={
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': f'Bearer {token}',
            },
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


@app.route('/api/submit-project', methods=['POST'])
def submit_project():
    """Server-side project submission: verifies Supabase JWT, inserts via
    service key, and sends admin notification email — all in one trusted step.
    No secrets are ever sent to or read from the browser."""
    # 1. Authenticate via the user's Supabase session JWT
    auth_header = request.headers.get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        return {'ok': False, 'error': 'Unauthorized'}, 401
    user = _verify_supabase_token(auth_header[7:])
    if not user:
        return {'ok': False, 'error': 'Invalid or expired session'}, 401

    # 2. Parse and sanitise project data
    payload = request.get_json(silent=True) or {}
    name        = str(payload.get('name', '')).strip()[:200]
    description = str(payload.get('description', '')).strip()[:2000]
    if not name or not description:
        return {'ok': False, 'error': 'name and description are required'}, 400

    def _s(key, limit=500):
        v = payload.get(key)
        return str(v).strip()[:limit] if v else None

    new_project = {
        'name':        name,
        'description': description,
        'idea':        _s('idea'),
        'build_time':  _s('build_time', 200),
        'cost':        _s('cost', 200),
        'demo':        _s('demo', 500) or '#',
        'tools':       [str(t).strip()[:100] for t in (payload.get('tools') or []) if str(t).strip()][:20],
        'score':       None,
        'author':      _s('author', 100) or '@anon',
        'emoji':       _s('emoji', 10) or '🚀',
        'cat':         _s('cat', 100) or 'Other',
        'upvotes':     0,
        'status':      'pending',
    }

    # 3. Insert using service key (bypasses RLS — safe because we verified the JWT)
    _, err = _sb_service_request('POST', 'projects', new_project)
    if err:
        return {'ok': False, 'error': f'DB error: {err}'}, 500

    # 4. Send admin notification email — failure is non-blocking
    admin_url = (BASE_URL_OVERRIDE or request.host_url.rstrip('/')) + '/admin'
    email_body = (
        f"New project submitted for review on CheckMyVibeCode!\n\n"
        f"Name:        {name}\n"
        f"Author:      {new_project['author']}\n"
        f"Category:    {new_project['cat']}\n"
        f"Demo URL:    {new_project['demo']}\n"
        f"Description: {description[:300]}\n\n"
        f"Review it here: {admin_url}\n"
    )
    ok, email_err = _send_resend_email(
        to='contact@checkmyvibecode.com',
        subject=f'[CheckMyVibeCode] New submission: {name}',
        text_body=email_body,
    )
    if not ok:
        app.logger.warning('Submit email notify failed: %s', email_err)

    return {'ok': True}, 201


# ── Catch-all static file route ───────────────────────────────────────────────

@app.route('/<path:path>')
def root_files(path):
    if path in HTML_ENTRY_POINTS:
        return redirect(url_for('index'), code=301)
    filename = os.path.basename(path)
    if filename.startswith('.') or filename in BLOCKED_NAMES:
        abort(404)
    safe_path = os.path.normpath(os.path.join(BASE_DIR, path))
    if os.path.commonpath([BASE_DIR, safe_path]) != BASE_DIR:
        abort(404)
    if not os.path.isfile(safe_path):
        abort(404)
    return send_from_directory(BASE_DIR, path)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
